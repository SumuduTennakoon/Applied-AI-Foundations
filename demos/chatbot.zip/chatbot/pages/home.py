import streamlit as st

st.title("Chatbot Demo App")
st.header("Applied AI Foundations: An introduction to your AI Journey")
st.subheader("A Course by Sumudu Tennakoon, PhD")
st.write("https://github.com/SumuduTennakoon/Applied-AI-Foundations")
st.write("https://www.datasciencefoundations.com")


st.subheader("Setup Ollama for LLM Inference in your own Computer") 
st.markdown("""
### Steps:
1. Download and Install Ollama: https://ollama.com/download
2. Pull a model into local environemnt: `ollama pull llama3.2:1b`
3. Run model for inference: `ollama run llama3.2:1b`
4. Install Ollama Python library: `pip install ollama`
5. Execute sample code below
""")

st.subheader("Ollama Documentation")
st.write("https://docs.ollama.com/quickstart#python")

st.subheader("Streamlit References")
st.write("https://docs.streamlit.io/develop/tutorials/chat-and-llm-apps/build-conversational-apps")

