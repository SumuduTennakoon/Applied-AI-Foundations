import streamlit as st

knowledge = st.text_area("Add text for Chatbot Knowladgde:", 
                            height=500,  
                            value=st.session_state["knowledge"].replace("\\n", "\n"),
                            placeholder="Type your text here...")
if knowledge:
    st.session_state["knowledge"] = knowledge
    st.success("Knowledge in use")