import streamlit as st
from ollama import chat

def get_llm_answer(chat_history, instructions, knowledge, model):
    """
    Generate a language model response based on chat history, system instructions, and domain knowledge.

    Parameters
    ----------
    chat_history : list
        A list of prior conversation messages, each represented as a dictionary
        with 'role' and 'content' keys.
    instructions : str
        System-level guidance or rules for the model.
    knowledge : str
        Additional contextual knowledge to include in the system prompt.
    model : str
        The identifier of the language model to query.

    Returns
    -------
    str
        The content of the model's response message as string.
    """

    system_prompt = [{
        'role': 'system',
        'content': instructions + "\n\n---" + knowledge
    }]

    messages = system_prompt + chat_history

    response = chat(model=model, messages=messages)

    llm_output = response['message']['content']

    return response['message']['content'] 

#  Streamlit App ##############################################################
st.title("🤖 NovaTron Chatbot")

if "model" not in st.session_state:
    st.session_state["model"] ="llama3.2:1b"

if "instructions" not in st.session_state:
    st.session_state["instructions"] = """
        You are a chatbot assistant helping users with science questions. \
        Be polite and professional in the answer for an accademic audience. \
        Use necessry formatting to improve the readability of the answer. \
        Provide diret and concise answers with some explnation to imoprove understanding of the science concepts.
        """

if "knowledge" not in st.session_state:
    st.session_state["knowledge"] = ""

if "messages" not in st.session_state:
    st.session_state["messages"] = []

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

if prompt := st.chat_input(f"Hello {st.session_state.user_name}, How can I help you?"):
    st.session_state.messages.append({"role": "user", "content": prompt})
    
    with st.chat_message("user"):
        st.markdown(prompt)

    chat_history = [ {"role": msg["role"], "content": msg["content"]} for msg in st.session_state["messages"] ]

    answer = get_llm_answer(chat_history=chat_history, 
                            instructions=st.session_state["instructions"], 
                            knowledge=st.session_state["knowledge"], 
                            model=st.session_state["model"])

    with st.chat_message("assistant"):
        st.markdown(answer)

    st.session_state.messages.append({"role": "assistant", "content": answer})