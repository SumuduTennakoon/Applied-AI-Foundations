import streamlit as st

instructions = st.text_area("Add text for Chatbot Instructions:", 
                            height=500,  
                            value=st.session_state["instructions"],
                            placeholder="Type your text here...")
if instructions:
    st.session_state["instructions"] = instructions
    st.info("Instructions in use")