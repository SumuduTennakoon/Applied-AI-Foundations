import streamlit as st
import textwrap #built‑in Python module that helps you format and clean up text

st.set_page_config(page_title="Chatbot Demo App", page_icon="🏠", layout="centered")

if "model" not in st.session_state:
    st.session_state["model"] ="llama3.2:1b"

if "instructions" not in st.session_state:
    st.session_state["instructions"] = textwrap.dedent("""\
        You are a chatbot assistant helping users with science questions.
        * Be polite and professional in the answer for an academic audience.
        * Use necessary formatting to improve the readability of the answer.
        * Provide direct and concise answers with some explanation to improve understanding of the science concepts.
    """)


if "knowledge" not in st.session_state:
    st.session_state["knowledge"] = ""

# Sidebar user input (shared across all pages)
with st.sidebar:
    if "user_name" not in st.session_state:
        st.session_state["user_name"] = ""
    name = st.text_input("Enter your name:", value=st.session_state["user_name"])
    if name:
        st.session_state["user_name"] = name
        st.success("Hello " + st.session_state["user_name"])

# Navigation
nav = st.navigation(
    {
        "Pages": [
            st.Page("pages\home.py", title="🏠 Home"),
            st.Page("pages\chatbot.py", title="🤖 Chatbot Demo"),
            st.Page("pages\instructions.py", title=" ✍️ Instructions"),
            st.Page("pages\knowledge.py", title="📚 Knowledge"),
            
        ],
    }
)



nav.run()
