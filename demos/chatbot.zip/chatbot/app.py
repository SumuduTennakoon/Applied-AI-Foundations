import streamlit as st

st.set_page_config(page_title="Chatbot Demo App", page_icon="🏠", layout="centered")

# Sidebar user input (shared across all pages)
with st.sidebar:
    if "user_name" not in st.session_state:
        st.session_state["user_name"] = ""
    name = st.text_input("Enter your name:", value=st.session_state["user_name"])
    if name:
        st.session_state["user_name"] = name
        st.success("Hello " + st.session_state["user_name"])

# Navigation
nav = st.navigation(
    {
        "Main": [
            st.Page("pages\home.py", title="🏠 Home"),
        ],
        "Apps": [
            st.Page("pages\chatbot.py", title="🤖 Chatbot Demo"),
        ],
    }
)

nav.run()
